مشروع أندرويد جاهز لبناء ملف APK لتطبيق العجلة الدوارة
======================================================

يحتوي هذا المجلد على نسختك المحدّثة من ملف العجلة الدوارة داخل:
app/src/main/assets/index.html

الطريقة 1 (عبر Android Studio):
1. فك الضغط وافتح المجلد في Android Studio.
2. انتظر انتهاء Gradle Sync.
3. من القائمة العلوية اختر: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. ستجد ملف APK في: app/build/outputs/apk/debug/app-debug.apk

الطريقة 2 (دون تثبيت Android Studio — عبر GitHub Actions):
1. أنشئ مستودعاً جديداً على GitHub وارفع محتويات هذا المجلد إليه.
2. افتح تبويب Actions داخل المستودع؛ سيُبنى التطبيق تلقائياً خلال دقيقتين.
3. حمّل الملف الجاهز classroom-wheel-apk من قسم Artifacts.
